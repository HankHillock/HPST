package hankathan.hpstmod;

import java.awt.Color;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.RemnantStationFleetManager;
import com.fs.starfarer.api.impl.campaign.procgen.themes.MiscellaneousThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SectorThemeGenerator;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.util.Misc;

import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import org.lazywizard.lazylib.VectorUtils;
import org.magiclib.util.MagicCampaign;

public class hpstModPlugin extends BaseModPlugin {

    @Override
    public void onNewGame() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.createStarSystem("XJ-471A");

        //It's by no means necessary to set a background to your star system.
        //However, let's see how to do it.
        //If you prefer a non-descript star field, simply disable this line.
        system.setBackgroundTextureFilename("graphics/backgrounds/hlbg1.png");

        //We'll use this particular API to instantiate the star.
        //It allows us to set the position without having to also maintain an
        //external file to set the hyperspace position.
        //This is convenient for this example.
        //But if you add lots of stars with your mod and want to keep track of their positions
        //relative to each other, the external settings file can also be convenient.
        //PlanetAPI initStar(
        //    id, //unique id for this star. This is how we retrieve it!
        //    type, //You can refer to com.fs.starfarer.api.impl.campaign.ids.StarTypes or
        //		use the actual values found in
        //		\Starsector\starsector-core\data\config\planets.json
        //    radius, //The rest are pretty obvious!
        //    hyperspaceLocationX,
        //    hyperspaceLocationY,
        //    coronaSize) // corona radius, from star edge

        PlanetAPI hill_star = system.initStar(
                "hillockstar",
                "star_yellow",
                410,
                75200,
                41400,
                200);
        PlanetAPI barr_star = system.addPlanet(
                "barrowstar",
                hill_star,
                "XJ-471B",
                "star_white",
                0,
                190,
                12000,
                480);
        system.setSecondary(barr_star);
        system.setType(StarSystemGenerator.StarSystemType.BINARY_FAR);

        SectorEntityToken systemstablepoint = system.addCustomEntity(
                null,
                null,
                "stable_location",
                Factions.NEUTRAL
        );
        systemstablepoint.setLocation(6500, 500);

        int count = StarSystemGenerator.random.nextInt(10) + 10;
        for (int i = 0; i < count; i++) {
            float amount = StarSystemGenerator.random.nextFloat() * 200f + 100f;
            float density = StarSystemGenerator.random.nextFloat() * 0.5f + 0.5f;
            DebrisFieldTerrainPlugin.DebrisFieldParams params = new DebrisFieldTerrainPlugin.DebrisFieldParams(
                    amount / density, // field radius - should not go above 1000 for performance reasons
                    density / 3f, // density, visual - affects number of debris pieces
                    10000000f, // duration in days
                    0f); // days the field will keep generating glowing pieces
            params.source = DebrisFieldTerrainPlugin.DebrisFieldSource.BATTLE;
            params.baseSalvageXP = 500; // base XP for scavenging in field
            SectorEntityToken debris = Misc.addDebrisField(system, params, StarSystemGenerator.random);
            debris.setDiscoverable(true);
            debris.setSensorProfile(amount);

            float r = StarSystemGenerator.random.nextFloat();
            if (r < 0.2) {
                debris.setCircularOrbit(hill_star, StarSystemGenerator.random.nextFloat() * 360f,
                        StarSystemGenerator.random.nextFloat() * 300f + 2000f, 35);
            } else if (r < 0.7) {
                debris.setCircularOrbit(hill_star, StarSystemGenerator.random.nextFloat() * 360f,
                        StarSystemGenerator.random.nextFloat() * 900f + 3200f, 180);
            } else {
                debris.setCircularOrbit(hill_star, StarSystemGenerator.random.nextFloat() * 360f,
                        StarSystemGenerator.random.nextFloat() * 1200f + 5500f, 705);
            }
        }

        // HILLOCK PLANETS AND ORBITS

        PlanetAPI hellsmuth = system.addPlanet("hellsmuth", hill_star, "XJ-471A-I", "lava", 20, 100, 1100, 8);
        Misc.initConditionMarket(hellsmuth);

        MarketAPI newMarket = Global.getFactory().createMarket("hellsmuth_marketId", hellsmuth.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_SCATTERED);
        newMarket.addCondition(Conditions.EXTREME_TECTONIC_ACTIVITY);
        newMarket.addCondition(Conditions.VERY_HOT);
        newMarket.addCondition(Conditions.RARE_ORE_ULTRARICH);
        newMarket.addCondition(Conditions.ORE_ULTRARICH);
        newMarket.setPrimaryEntity(hellsmuth);
        hellsmuth.setMarket(newMarket);


        PlanetAPI rudo = system.addPlanet("rudo", hill_star, "XJ-471A-IV", "barren", 10, 50, 3920, 23);
        Misc.initConditionMarket(rudo);

        newMarket = Global.getFactory().createMarket("rudo_marketId", rudo.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.NO_ATMOSPHERE);
        newMarket.addCondition(Conditions.ORE_SPARSE);
        newMarket.addCondition(Conditions.LOW_GRAVITY);
        newMarket.setPrimaryEntity(rudo);
        rudo.setMarket(newMarket);


        PlanetAPI dartsbluth = system.addPlanet("dartsbluth", hill_star, "XJ-471A-II", "desert", 10, 140, 2490, 13);
        Misc.initConditionMarket(dartsbluth);

        newMarket = Global.getFactory().createMarket("dartsbluth_marketId", dartsbluth.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_WIDESPREAD);
        newMarket.addCondition(Conditions.ORE_SPARSE);
        newMarket.addCondition(Conditions.ORGANICS_TRACE);
        newMarket.addCondition(Conditions.HOT);
        newMarket.setPrimaryEntity(dartsbluth);
        dartsbluth.setMarket(newMarket);


        PlanetAPI laynear = system.addPlanet("laynear", hill_star, "XJ-471A-III", "jungle", 15, 165, 3080, 19);
        Misc.initConditionMarket(laynear);

        newMarket = Global.getFactory().createMarket("laynear_marketId", laynear.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_EXTENSIVE);
        newMarket.addCondition(Conditions.HABITABLE);
        newMarket.addCondition(Conditions.INIMICAL_BIOSPHERE);
        newMarket.addCondition(Conditions.HOT);
        newMarket.addCondition(Conditions.ORGANICS_PLENTIFUL);
        newMarket.addCondition(Conditions.FARMLAND_BOUNTIFUL);
        newMarket.setPrimaryEntity(laynear);
        laynear.setMarket(newMarket);

        CampaignFleetAPI fleet1 = FleetFactoryV3.createEmptyFleet("remnant", "battlestation", null);

        fleet1.getFleetData().addFleetMember("remnant_station2_Standard");
        fleet1.getMemoryWithoutUpdate().set("$cfai_makeAggressive", Boolean.valueOf(true));
        fleet1.getMemoryWithoutUpdate().set("$cfai_noJump", Boolean.valueOf(true));
        fleet1.getMemoryWithoutUpdate().set("$cfai_makeAllowDisengage", Boolean.valueOf(true));
        fleet1.setStationMode(Boolean.valueOf(true));
        system.addEntity(fleet1);

        fleet1.clearAbilities();
        fleet1.addAbility("transponder");
        fleet1.getAbility("transponder").activate();
        fleet1.getDetectedRangeMod().modifyFlat("gen", 1000.0F);
        fleet1.setCircularOrbitWithSpin(
                laynear, // focus
                60,// angle
                350, // orbitRadius, was radius_fleet1, useful if random location in system
                24f, // orbitDays
                7f, // minSpin
                12f // maxSpin
        );
        fleet1.setAI(null);
        PersonAPI commander1 = OfficerManagerEvent.createOfficer(
                Global.getSector().getFaction("remnant"), 10, true);
        commander1.getStats().setSkillLevel("gunnery_implants", 3.0F);
        fleet1.setCommander(commander1);
        fleet1.getFlagship().setCaptain(commander1);
        fleet1.getCargo().addCommodity(Commodities.ALPHA_CORE, 1f);
        fleet1.getCargo().addCommodity(Commodities.BETA_CORE, 3f);
        fleet1.getCargo().addCommodity(Commodities.GAMMA_CORE, 5f);
        fleet1.getCargo().addCommodity(Commodities.HEAVY_MACHINERY, 800f);
        fleet1.getCargo().addCommodity(Commodities.RARE_METALS, 500f);
        fleet1.getCargo().addCommodity(Commodities.METALS, 1000f);

        RemnantStationFleetManager RemnFleets = new RemnantStationFleetManager(
                fleet1, 1.0f, 1,4, 30, 30, 90);
        system.addScript(RemnFleets);

        SectorEntityToken gate = system.addCustomEntity("hillock_gate", // unique id
                "XJ-471A Gate", // name - if null, defaultName from custom_entities.json will be used
                "inactive_gate", // type of object, defined in custom_entities.json
                null); // faction
        gate.setCircularOrbit(system.getEntityById("hillockstar"), 0, 5200, 310);

        system.addAsteroidBelt(hill_star, 180, 6250, 1000, 150, 300, Terrain.ASTEROID_BELT, "Asteroid Belt");
        system.addRingBand(hill_star, "misc", "rings_dust0", 256f, 3, Color.white, 256f, 5600, 305f, null, "Asteroid Belt");
        system.addRingBand(hill_star, "misc", "rings_asteroids0", 256f, 3, Color.white, 256f, 5720, 295f, null, "Asteroid Belt");


        // BARROW PLANETS AND ORBITS

        PlanetAPI westrun = system.addPlanet("westrun", barr_star, "XJ-471B-II", "arid", 15, 120, 1660, 11);
        Misc.initConditionMarket(westrun);

        newMarket = Global.getFactory().createMarket("westrun_marketId", westrun.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_EXTENSIVE);
        newMarket.addCondition(Conditions.HABITABLE);
        newMarket.addCondition(Conditions.POLLUTION);
        newMarket.addCondition(Conditions.MILD_CLIMATE);
        newMarket.addCondition(Conditions.FARMLAND_POOR);
        newMarket.addCondition(Conditions.ORE_MODERATE);
        newMarket.addCondition(Conditions.ORGANICS_COMMON);
        newMarket.addCondition(Conditions.TECTONIC_ACTIVITY);
        newMarket.setPrimaryEntity(westrun);
        westrun.setMarket(newMarket);


        CampaignFleetAPI fleet2 = FleetFactoryV3.createEmptyFleet("remnant", "battlestation", null);

        fleet2.getFleetData().addFleetMember("remnant_station2_Standard");
        fleet2.getMemoryWithoutUpdate().set("$cfai_makeAggressive", Boolean.valueOf(true));
        fleet2.getMemoryWithoutUpdate().set("$cfai_noJump", Boolean.valueOf(true));
        fleet2.getMemoryWithoutUpdate().set("$cfai_makeAllowDisengage", Boolean.valueOf(true));
        fleet2.setStationMode(Boolean.valueOf(true));
        system.addEntity(fleet2);

        fleet2.clearAbilities();
        fleet2.addAbility("transponder");
        fleet2.getAbility("transponder").activate();
        fleet2.getDetectedRangeMod().modifyFlat("gen", 1000.0F);
        fleet2.setCircularOrbitWithSpin(
                westrun, // focus
                60,// angle
                300, // orbitRadius, was radius_fleet1, useful if random location in system
                24f, // orbitDays
                7f, // minSpin
                12f // maxSpin
        );
        fleet2.setAI(null);
        PersonAPI commander2 = OfficerManagerEvent.createOfficer(
                Global.getSector().getFaction("remnant"), 10, true);
        commander2.getStats().setSkillLevel("gunnery_implants", 3.0F);
        fleet2.setCommander(commander2);
        fleet2.getFlagship().setCaptain(commander2);
        fleet2.getCargo().addCommodity(Commodities.ALPHA_CORE, 1f);
        fleet2.getCargo().addCommodity(Commodities.BETA_CORE, 3f);
        fleet2.getCargo().addCommodity(Commodities.GAMMA_CORE, 5f);
        fleet2.getCargo().addCommodity(Commodities.HEAVY_MACHINERY, 800f);
        fleet2.getCargo().addCommodity(Commodities.RARE_METALS, 500f);
        fleet2.getCargo().addCommodity(Commodities.METALS, 1000f);

        RemnantStationFleetManager RemnFleets2 = new RemnantStationFleetManager(
        fleet2, 1.0f, 1,4, 30, 30, 90);
        system.addScript(RemnFleets2);

        PlanetAPI crevasse = system.addPlanet("crevasse", barr_star, "XJ-471B-III", "frozen", 5, 95, 3030, 22);
        Misc.initConditionMarket(crevasse);

        newMarket = Global.getFactory().createMarket("crevasse_marketId", crevasse.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_SCATTERED);
        newMarket.addCondition(Conditions.VERY_COLD);
        newMarket.addCondition(Conditions.RARE_ORE_MODERATE);
        newMarket.addCondition(Conditions.VOLATILES_DIFFUSE);
        newMarket.addCondition(Conditions.LOW_GRAVITY);
        newMarket.setPrimaryEntity(crevasse);
        crevasse.setMarket(newMarket);


        PlanetAPI hunloon = system.addPlanet("hunloon", barr_star, "XJ-471B-I", "water", 10, 105, 850, 8);
        Misc.initConditionMarket(hunloon);

        newMarket = Global.getFactory().createMarket("hunloon_marketId", hunloon.getName(), 0);
        newMarket.setPlanetConditionMarketOnly(true);
        newMarket.addCondition(Conditions.RUINS_WIDESPREAD);
        newMarket.addCondition(Conditions.EXTREME_WEATHER);
        newMarket.addCondition(Conditions.HABITABLE);
        newMarket.addCondition(Conditions.ORGANICS_ABUNDANT);
        newMarket.addCondition(Conditions.WATER_SURFACE);
        newMarket.setPrimaryEntity(hunloon);
        hunloon.setMarket(newMarket);




        //To make the star appear correctly in the game it is necessary to add hyperspace points.
        //This is the easiest way to handle it.
        //In this case we want to make sure we add a fringe jump point or else no one will be able to leave
        //our star system without a transverse jump! So the second "true" is kind of important.
        //autogenerateHyperspaceJumpPoints(
        //	boolean generateEntrancesAtGasGiants, //Create jump point at our gas giants?
        //	boolean generateFringeJumpPoint) //Create a jump point at the edge of the system?
        system.autogenerateHyperspaceJumpPoints(false, true);

        //Finally, as an added bonus let's examine how to add custom descriptions to our star system.
        //The game provides defaults based on the planet and star types we used above.
        //But we can customize them!
        hill_star.setCustomDescriptionId("hpst_hill");
        barr_star.setCustomDescriptionId("hpst_barr");

        hunloon.setCustomDescriptionId("hpst_hunloon");
        westrun.setCustomDescriptionId("hpst_westrun");
        crevasse.setCustomDescriptionId("hpst_crevasse");

        hellsmuth.setCustomDescriptionId("hpst_hellsmuth");
        dartsbluth.setCustomDescriptionId("hpst_dartsbluth");
        laynear.setCustomDescriptionId("hpst_laynear");
        rudo.setCustomDescriptionId("hpst_rudo");


        //Unfortunatley, this means we need to add the custom strings in a separate .csv file.
        //This file is in: ../data/string/descriptions.csv
        //(ie /Starsector/mods/MakeAStar/data/string/descriptions.csv)
        //The .csv has 6 columns and can be edited with any text editor.
        //The first column is the id, which we supply below.
        //We can use the same description more than once!
        //This is a separate description with a different id.
        //The second column is the type, which is CUSTOM.
        //Any id that is used with setCustomDescriptionId needs to have the type CUSTOM.
        //The third column is "text1", which for our planets and stars is the main description.
        //This is the most important description to set.
        //The forth column is "text2", which is a title show when a player puts the mouse over the planet or star.
        //This is optional and will override the more generic title the game provides by default.
        //The fifth column is "text3", which is a description show when the player approaches the planet or star.

        //The .csv file contains an example of how to use carriage returns for formatting paragraphs.
        //Use carriage returns with caution. It is very easy to mess up your .csv file if you get it wrong.
    }
}